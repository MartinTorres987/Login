<?php
require 'database.php';
$db = conectarDB();

// Autenticar el usuario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $mail = $_POST['mail'];
    $contra = $_POST['contra'];

    $contraseñaSegura = password_hash($contra, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (nombre, apellido, mail, contra) VALUES ('$name','$apellido','$mail','${contraseñaSegura}')";

    $resultado = mysqli_query($db, $sql);

    if ($resultado) {
        header("Location: bienvenida.php");
    }
}

?>

<!DOCTYPE html>
<html>
<body>
<head>
    <title>Registrar Usuario</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="xd.css">
</head>
</body>
    <form class="caja" method="POST" id="nombre" action="index.php">
        <h1>!Suscribete¡</h1>
         <div>
          <input type="text" name="nombre" class="box" require placeholder="Ingresa tu nombre" required>
        </div>
        <div>
            <br>
         <input type="text" name="apellido" class="box" require placeholder="Ingresa tu apellido" required>
        </div>

        <br>
        <div>
          <input type="email" name="mail" class="box" require placeholder="Ingresa tu correo" required>
        </div>
        <br>

        <div>
         <input type="password" name="contra" class="box" require placeholder="Ingresa tu contraseña" required>
        </div>
        <br>
        <div>
         <input type="submit" name="enviar" id="enviar">
        </div>
    </form>
</div>  


</html>