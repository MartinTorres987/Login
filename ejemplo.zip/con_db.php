<?php
require 'database.php';
$db = conectarDB();

$errores = [];

// Autenticar el usuario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['mail'];
    $pass = $_POST['contra'];

        // Revisar si el usuario existe
        $query = "SELECT * FROM users WHERE mail = '${email}' ";
        $resultado = mysqli_query($db, $query);

        if ($resultado->num_rows) {
            // Revisar si el password es correcto
            $usuario = mysqli_fetch_assoc($resultado);
            // Verificar  si el password es correcto o no
            $auth = password_verify($pass, $usuario['contra']);

            if ($auth) {
                // El usuario esta autenticado
                session_start();

                // Llenar el arreglo de la sesión 
                $_SESSION['usuario'] = $usuario['mail'];
                $_SESSION['login'] = true;

                    header("Location: bienvenida.php");

                // ...
            } else {
                echo ('Contraseña incorrecta');
            }
        } else {
            echo ('Usuario no existe');
        }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="xd.css">

</head>
<body>
    
</body>
</html>
<main class="contenedor seccion contenido-centrado">
    <h1>Iniciar Sesión</h1>

    <?php foreach ($errores as $error) : ?>
        <div class="alerta error">
            <?php echo $error ?>
        </div>

    <?php endforeach ?>
    <br>
    <form method="POST" class="caja" novalidate>
        <fieldset>
            <legend>Email y Password</legend>

            <label for="email">E-mail</label>
            <input type="email" name="mail" placeholder="Tu Email" id="email"></input>

            <label for="pass">Password</label>
            <input type="password" name="contra" placeholder="Tu Contraseña" id="password"></input>
        </fieldset>
        
        <input type="submit" value="Iniciar Sesión" class="boton-verde">
        <h3>Registrarse</h3>
    </form>
</main>
